# FLYING_ARROWS
Play FLYING ARROWS as a standalone .exe program





CONTROLS:

ARROWS    -> move the archer character

A         -> throw an arrow

S         -> jump

SPACEBAR  -> change arrow' type

ENTER     -> restart the map


Right-Click on screen opens a menu. Here you can configure buttons and other preferences. It is based on the BGB emulator.
